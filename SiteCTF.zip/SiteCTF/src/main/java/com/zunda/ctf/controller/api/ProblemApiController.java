package com.zunda.ctf.controller.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.zunda.ctf.entity.Problem;
import com.zunda.ctf.service.ProblemService;

import java.util.List;

@RestController
@RequestMapping("api/problems")
public class ProblemApiController {
	@Autowired
	ProblemService problemService;

	@RequestMapping(method = RequestMethod.GET)
	List<Problem> getProblems() {
		return problemService.findAll();
	}

	@RequestMapping(method = RequestMethod.POST)
	@ResponseStatus(HttpStatus.CREATED)
	Problem insertProblem(@Validated @RequestBody Problem problem) {
		return problemService.save(problem);
	}

	@RequestMapping(value = "{id}", method = RequestMethod.PUT)
	@ResponseStatus(HttpStatus.OK)
	Problem updateProblem(@PathVariable("id") Long id, @Validated @RequestBody Problem problem) {
		System.out.println("###### " + id + " ######");
		problem.setId(id);
		return problemService.save(problem);
	}

	@RequestMapping(value = "{id}", method = RequestMethod.DELETE)
	@ResponseStatus(HttpStatus.OK)
	void deleteProblem(@PathVariable("id") Long id) {
		problemService.delete(id);
	}

	@RequestMapping(value = "{id}", method = RequestMethod.GET)
	Problem getProblem(@PathVariable("id") Long id) {
		System.out.println("###### " + id + " ######");
		return problemService.find(id);
	}
}
