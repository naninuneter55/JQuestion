package com.zunda.ctf.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.zunda.ctf.entity.Problem;
import com.zunda.ctf.service.ProblemService;

@Controller
//@RestController
public class ProblemController {

	@Autowired
	ProblemService problemService;

	@RequestMapping("/ctf/problems")
	public ModelAndView index(ModelAndView mav) {
		List<Problem> problems = problemService.findAll();
		mav.addObject("problems", problems);
		mav.setViewName("index");
		return mav;
	}
}
