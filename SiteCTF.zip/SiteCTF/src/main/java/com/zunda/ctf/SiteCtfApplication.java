package com.zunda.ctf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SiteCtfApplication {

	public static void main(String[] args) {
		SpringApplication.run(SiteCtfApplication.class, args);
	}
}
