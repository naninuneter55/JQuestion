package com.zunda.ctf.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.zunda.ctf.entity.Problem;
import com.zunda.ctf.repository.ProblemRepository;

import java.util.List;

@Service
@Transactional
public class ProblemService {
	@Autowired
	ProblemRepository problemRepository;

	public List<Problem> findAll() {
		return problemRepository.findAll(new Sort(Sort.Direction.ASC, "id"));
	}

	public Problem save(Problem problem) {
		return problemRepository.save(problem);
	}

	public void delete(Long id) {
		problemRepository.delete(id);
	}

	public Problem find(Long id) {
		return problemRepository.findOne(id);
	}
}
