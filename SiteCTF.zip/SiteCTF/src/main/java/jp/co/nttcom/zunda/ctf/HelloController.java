package jp.co.nttcom.zunda.ctf;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Controller
//@RestController
public class HelloController {

	@RequestMapping("/")
	public String index() {
		return "index";
		//return "Hello Spring-Boot World!!";
	}
}
